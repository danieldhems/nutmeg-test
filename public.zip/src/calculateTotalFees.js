const calculateTotalFees = (
  startingContribution,
  monthlyContribution,
  months
) => {};

export default calculateTotalFees;
